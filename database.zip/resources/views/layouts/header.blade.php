<header style="background:#333; color:#fff; padding:10px;">
  <h2>Fleet Management System</h2>
</header>
