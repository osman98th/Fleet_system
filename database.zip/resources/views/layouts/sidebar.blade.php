<aside style="width:200px; background:#f4f4f4; height:100vh; float:left; padding:15px;">
  <h3>Menu</h3>
  <ul>
    <li><a href="/dashboard">Dashboard</a></li>
    <li><a href="/logout">Logout</a></li>
  </ul>
</aside>


