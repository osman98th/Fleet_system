@extends('layouts.app')

@section('title','Costs List')

@section('content')
<div class="container py-4">
    <h3>💰 Costs List</h3>

    <a href="{{ route('costs.create') }}" class="btn btn-primary mb-3">➕ Add Cost</a>

    <div class="card shadow-sm">
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>Vehicle</th>
                        <th>Name</th>
                        <th>Amount (৳)</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($costs as $key => $cost)
                    <tr>
                        <td>{{ $key + 1 }}</td>
                        <td>{{ \Carbon\Carbon::parse($cost->date)->format('d M Y') }}</td>
                        <td>{{ $cost->vehicle ? $cost->vehicle->name : '-' }}</td>
                        <td>{{ $cost->name }}</td>
                        <td>{{ number_format($cost->amount,2) }}</td>
                        <td>
                            <a href="{{ route('costs.edit', $cost->id) }}" class="btn btn-sm btn-info">Edit</a>
                            <form action="{{ route('costs.destroy', $cost->id) }}" method="POST" class="d-inline-block" onsubmit="return confirm('Are you sure?');">
                                @csrf
                                @method('DELETE')
                                <button class="btn btn-sm btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                    @if($costs->isEmpty())
                    <tr>
                        <td colspan="6" class="text-center">No costs found.</td>
                    </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection