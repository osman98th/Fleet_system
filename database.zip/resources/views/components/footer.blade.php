<!-- resources/views/components/footer.blade.php -->
<footer class="bg-gray-800 text-white py-4 mt-10 text-center">
    &copy; {{ date('Y') }} {{ config('app.name') }}. All rights reserved.
</footer>
