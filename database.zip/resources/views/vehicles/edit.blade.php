@extends('layouts.app')
@section('title', 'Edit Vehicle')

@section('content')
<div class="container py-4">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="mb-0">🚗 Edit Vehicle</h3>
        <a href="{{ route('vehicles.index') }}" class="btn btn-secondary btn-sm">← Back to List</a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">

            <form action="{{ route('vehicles.update', $vehicle->id) }}" method="POST" class="row g-3">
                @csrf
                @method('PUT')
                <div class="col-md-6">
                    <label for="vehicle_name" class="form-label">Vehicle Name</label>
                    <input type="text" name="vehicle_name" id="vehicle_name" class="form-control" 
                           value="{{ old('vehicle_name', $vehicle->vehicle_name) }}" required>
                </div>
                <div class="col-md-6">
                    <label for="model" class="form-label">Model</label>
                    <input type="text" name="model" id="model" class="form-control" 
                           value="{{ old('model', $vehicle->model) }}" required>
                </div>
                <div class="col-md-6">
                    <label for="license_plate" class="form-label">License Plate</label>
                    <input type="text" name="license_plate" id="license_plate" class="form-control" 
                           value="{{ old('license_plate', $vehicle->license_plate) }}" required>
                </div>
                <div class="col-md-6">
                    <label for="year" class="form-label">Year</label>
                    <input type="number" name="year" id="year" class="form-control" 
                           value="{{ old('year', $vehicle->year) }}">
                </div>
                <div class="col-md-6">
                    <label for="type" class="form-label">Vehicle Type</label>
                    <select name="type" id="type" class="form-select" required>
                        <option value="Car" {{ old('type', $vehicle->type) == 'Car' ? 'selected' : '' }}>Car</option>
                        <option value="Truck" {{ old('type', $vehicle->type) == 'Truck' ? 'selected' : '' }}>Truck</option>
                        <option value="Bus" {{ old('type', $vehicle->type) == 'Bus' ? 'selected' : '' }}>Bus</option>
                        <option value="Van" {{ old('type', $vehicle->type) == 'Van' ? 'selected' : '' }}>Van</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="status" class="form-label">Status</label>
                    <select name="status" id="status" class="form-select" required>
                        <option value="Active" {{ old('status', $vehicle->status) == 'Active' ? 'selected' : '' }}>Active</option>
                        <option value="Inactive" {{ old('status', $vehicle->status) == 'Inactive' ? 'selected' : '' }}>Inactive</option>
                    </select>
                </div>

                <div class="col-12 mt-3">
                    <button type="submit" class="btn btn-primary">💾 Update Vehicle</button>
                </div>
            </form>

        </div>
    </div>

</div>
@endsection
