<header class="header">
    <div class="logo">🚗 Fleet Management</div>
    <button id="menu-toggle" class="menu-btn">☰</button>
    <nav class="nav ">
        <a href="{{ route('dashboard') }}">Home</a>
        <a href="{{ route('reports.fuel') }}"  style="padding:0 20px">Reports</a>
        <a href="{{ route('login') }}"  style="padding:0 20px">login</a>
        <a href="{{ route('register') }}"  style="padding:0 20px">register</a>
        <a href="#">Settings</a>

    </nav>
</header>
