<footer class="footer">
    <p>© {{ date('Y') }} Fleet Management System. Developed by Osman Goni.</p>
</footer>
