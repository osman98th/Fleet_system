@extends('layouts.app')

@section('title','Fuel Report')

@section('content')
<div class="container py-4">
    <h3>⛽ Fuel Report</h3>

    {{-- Filter Form --}}
    <form action="{{ route('reports.fuel') }}" method="GET" class="row g-3 mb-4">
        <div class="col-md-4">
            <label for="vehicle_id" class="form-label">Vehicle</label>
            <select name="vehicle_id" id="vehicle_id" class="form-select">
                <option value="">-- All Vehicles --</option>
                @foreach(\App\Models\Vehicle::orderBy('name')->get() as $vehicle)
                <option value="{{ $vehicle->id }}" {{ request('vehicle_id') == $vehicle->id ? 'selected' : '' }}>
                    {{ $vehicle->name }}
                </option>
                @endforeach
            </select>
        </div>
        <div class="col-md-4">
            <label for="month" class="form-label">Month</label>
            <input type="month" name="month" id="month" class="form-control" value="{{ request('month') }}">
        </div>
        <div class="col-md-4 d-flex align-items-end">
            <button class="btn btn-primary me-2">Filter</button>
            <a href="{{ route('reports.fuel') }}" class="btn btn-secondary">Reset</a>
            <a href="{{ route('reports.fuel.pdf', request()->all()) }}" target="_blank" class="btn btn-success ms-2">PDF</a>
        </div>
    </form>

    {{-- Table --}}
    <div class="card shadow-sm">
        <div class="card-body table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>Vehicle</th>
                        <th>Driver</th>
                        <th>Fuel Cost (৳)</th>
                        <th>Other Costs (৳)</th>
                        <th>Total Cost (৳)</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($fuelRecords as $f)
                    @php
                    $otherCost = $vehicleCosts[$f->vehicle_id] ?? 0;
                    $totalCost = ($f->cost ?? 0) + $otherCost;
                    @endphp
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ \Carbon\Carbon::parse($f->date)->format('d M Y') }}</td>
                        <td>{{ $f->vehicle->name ?? '-' }}</td>
                        <td>{{ $f->driver->name ?? '-' }}</td>
                        <td>{{ number_format($f->cost,2) }}</td>
                        <td>{{ number_format($otherCost,2) }}</td>
                        <td>{{ number_format($totalCost,2) }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center">No fuel records found.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    {{-- Chart --}}
    @if(isset($chartImage))
    <div class="mt-4">
        <h5>Daily Fuel Cost Chart</h5>
        <img src="{{ $chartImage }}" alt="Fuel Cost Chart" class="img-fluid">
    </div>
    @endif
</div>
@endsection