@extends('layouts.app')

@section('title','Total Expense Report')

@section('content')
<div class="container py-4">
    <h3 class="mb-4 text-center">💰 Total Expense Report</h3>

    <div class="table-responsive">
        <table class="table table-bordered text-center" style="font-size:12px;">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Type</th>
                    <th>Date</th>
                    <th>Vehicle</th>
                    <th>Fuel</th>
                    <th>Maintenance</th>
                    <th>Food</th>
                    <th>Stipend</th>
                    <th>Parking</th>
                    <th>Toll</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                @foreach($records as $key => $r)
                <tr>
                    <td>{{ $key + 1 }}</td>
                    <td>{{ $r->type ?? '-' }}</td>
                    <td>{{ $r->date ?? '-' }}</td>
                    <td>{{ $r->vehicle->name ?? '-' }}</td>
                    <td>{{ number_format($r->fuel_cost ?? 0, 2) }}</td>
                    <td>{{ number_format($r->maintenance_cost ?? 0, 2) }}</td>
                    <td>{{ number_format($r->food_cost ?? 0, 2) }}</td>
                    <td>{{ number_format($r->stipend_cost ?? 0, 2) }}</td>
                    <td>{{ number_format($r->parking_cost ?? 0, 2) }}</td>
                    <td>{{ number_format($r->toll_cost ?? 0, 2) }}</td>
                    <td>{{ number_format(
                        ($r->fuel_cost ?? 0) +
                        ($r->maintenance_cost ?? 0) +
                        ($r->food_cost ?? 0) +
                        ($r->stipend_cost ?? 0) +
                        ($r->parking_cost ?? 0) +
                        ($r->toll_cost ?? 0), 2) 
                    }}</td>
                </tr>
                @endforeach
            </tbody>
            <tfoot class="table-light">
                <tr>
                    <th colspan="10" class="text-end">Grand Total:</th>
                    <th>{{ number_format($totalExpense ?? 0, 2) }}</th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
@endsection