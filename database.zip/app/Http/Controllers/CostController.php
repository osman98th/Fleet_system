<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cost;
use PDF;
use Carbon\Carbon;

class CostController extends Controller
{
    // Index
    public function index()
    {
        $costs = Cost::latest()->paginate(10);
        $totalMonthlyCost = Cost::whereMonth('date', Carbon::now()->month)
            ->whereYear('date', Carbon::now()->year)
            ->sum('amount');

        return view('costs.index', compact('costs', 'totalMonthlyCost'));
    }

    // Create
    public function create()
    {
        return view('costs.create');
    }

    // Store
    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'amount' => 'required|numeric|min:0',
            'date' => 'required|date',
        ]);

        Cost::create($data);
        return redirect()->route('costs.index')->with('success', 'Cost added successfully.');
    }

    // Edit
    public function edit(Cost $cost)
    {
        return view('costs.edit', compact('cost'));
    }

    // Update
    public function update(Request $request, Cost $cost)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'amount' => 'required|numeric|min:0',
            'date' => 'required|date',
        ]);

        $cost->update($data);
        return redirect()->route('costs.index')->with('success', 'Cost updated successfully.');
    }

    // Destroy
    public function destroy(Cost $cost)
    {
        $cost->delete();
        return redirect()->route('costs.index')->with('success', 'Cost deleted successfully.');
    }

    // PDF Report
    public function pdfReport()
    {
        $costs = Cost::latest()->get();
        $pdf = PDF::loadView('costs.pdf', compact('costs'))->setPaper('A4', 'landscape');
        return $pdf->download('cost-report.pdf');
    }
}
