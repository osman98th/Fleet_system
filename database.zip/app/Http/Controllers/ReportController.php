<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FuelRecord;
use App\Models\Cost;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Carbon\Carbon;

class ReportController extends Controller
{
    /**
     * Fuel Report Page
     */
    public function fuelReport(Request $request)
    {
        $query = FuelRecord::with(['vehicle', 'driver'])->orderBy('date', 'desc');

        if ($request->vehicle_id) {
            $query->where('vehicle_id', $request->vehicle_id);
        }

        if ($request->month) {
            $date = Carbon::parse($request->month);
            $query->whereMonth('date', $date->month)
                ->whereYear('date', $date->year);
        }

        $fuelRecords = $query->get();

        // Vehicle-wise total costs
        $vehicleCosts = Cost::select('vehicle_id', DB::raw('SUM(amount) as total_amount'))
            ->groupBy('vehicle_id')
            ->pluck('total_amount', 'vehicle_id')
            ->toArray();

        // Daily fuel cost chart
        $dailyData = FuelRecord::select(
            DB::raw('DATE(date) as date'),
            DB::raw('SUM(cost) as daily_cost')
        )
            ->groupBy(DB::raw('DATE(date)'))
            ->orderBy('date', 'asc')
            ->get();

        $labels = $dailyData->pluck('date')->map(fn($d) => date('d M', strtotime($d)))->toArray();
        $values = $dailyData->pluck('daily_cost')->toArray();

        $chartConfig = [
            'type' => 'bar',
            'data' => [
                'labels' => $labels,
                'datasets' => [[
                    'label' => 'Daily Fuel Cost',
                    'backgroundColor' => 'rgba(54, 162, 235, 0.6)',
                    'borderColor' => 'rgba(54, 162, 235, 1)',
                    'borderWidth' => 1,
                    'data' => $values
                ]]
            ],
            'options' => [
                'plugins' => ['legend' => ['display' => false]],
                'scales' => ['y' => ['beginAtZero' => true]]
            ]
        ];

        $chartImage = 'https://quickchart.io/chart?c=' . urlencode(json_encode($chartConfig));

        return view('reports.fuel', compact('fuelRecords', 'vehicleCosts', 'dailyData', 'chartImage'));
    }

    /**
     * Fuel PDF Download
     */
    public function fuelReportPdf(Request $request)
    {
        $query = FuelRecord::with(['vehicle', 'driver'])->orderBy('date', 'desc');

        if ($request->vehicle_id) $query->where('vehicle_id', $request->vehicle_id);
        if ($request->month) {
            $date = Carbon::parse($request->month);
            $query->whereMonth('date', $date->month)
                ->whereYear('date', $date->year);
        }

        $fuelRecords = $query->get();

        $vehicleCosts = Cost::select('vehicle_id', DB::raw('SUM(amount) as total_amount'))
            ->groupBy('vehicle_id')
            ->pluck('total_amount', 'vehicle_id')
            ->toArray();

        $pdf = Pdf::loadView('reports.fuel-pdf', compact('fuelRecords', 'vehicleCosts'))
            ->setPaper('A4', 'landscape');

        return $pdf->download('fuel-report.pdf');
    }

    /**
     * Total Expense Page
     */
    public function totalExpense(Request $request)
    {
        $records = $this->prepareExpenseRecords($request);

        $totalExpense = $records->sum(
            fn($r) => ($r->fuel_cost ?? 0) + ($r->maintenance_cost ?? 0) + ($r->food_cost ?? 0) +
                ($r->stipend_cost ?? 0) + ($r->parking_cost ?? 0) + ($r->toll_cost ?? 0)
        );

        return view('reports.total_expense', compact('records', 'totalExpense'));
    }

    /**
     * Total Expense PDF
     */
    public function totalExpensePdf(Request $request)
    {
        $records = $this->prepareExpenseRecords($request);

        $totalExpense = $records->sum(
            fn($r) => ($r->fuel_cost ?? 0) + ($r->maintenance_cost ?? 0) + ($r->food_cost ?? 0) +
                ($r->stipend_cost ?? 0) + ($r->parking_cost ?? 0) + ($r->toll_cost ?? 0)
        );

        $pdf = Pdf::loadView('reports.total_expense_pdf', compact('records', 'totalExpense'))
            ->setPaper('A4', 'landscape');

        return $pdf->download('total-expense-report.pdf');
    }

    /**
     * Prepare all expense records with optional filters
     */
    private function prepareExpenseRecords(Request $request)
    {
        $records = collect();
        $month = $request->month;
        $vehicleId = $request->vehicle_id;

        $filter = fn($q) => (
            ($month ? $q->whereMonth('date', Carbon::parse($month)->month)
                ->whereYear('date', Carbon::parse($month)->year) : null) &&
            ($vehicleId ? $q->where('vehicle_id', $vehicleId) : null)
        );

        $tables = [
            'fuel_records' => ['fuel_cost' => 'cost'],
            'maintenances' => ['maintenance_cost' => 'cost'],
            'foods' => ['food_cost' => 'cost'],
            'stipends' => ['stipend_cost' => 'amount'],
            'parkings' => ['parking_cost' => 'cost'],
            'tolls' => ['toll_cost' => 'cost']
        ];

        foreach ($tables as $table => $columns) {
            if (!Schema::hasTable($table)) continue;

            $data = DB::table($table)
                ->when($month || $vehicleId, $filter)
                ->get()
                ->map(fn($r) => (object) array_merge([
                    'type' => ucfirst(str_replace('_', ' ', $table)),
                    'fuel_cost' => 0,
                    'maintenance_cost' => 0,
                    'food_cost' => 0,
                    'stipend_cost' => 0,
                    'parking_cost' => 0,
                    'toll_cost' => 0,
                    'vehicle' => $table === 'fuel_records' ? FuelRecord::find($r->id)->vehicle : null,
                    'date' => $r->date
                ], $columns));

            $records = $records->merge($data);
        }

        return $records->sortByDesc('date');
    }
}
